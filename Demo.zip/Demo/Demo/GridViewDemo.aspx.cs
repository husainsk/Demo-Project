﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Demo
{
    public partial class GridViewDemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDataControl();
            }

        }

        private void BindDataControl()
        {
            string name = TextBox1.Text;
            string constr = ConfigurationManager.ConnectionStrings["MysqlConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("Cat_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "SELECT");
                    cmd.Connection = con;
                    SqlDataAdapter ada = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    ada.Fill(dt);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    RadioButtonList1.DataSource = dt;
                    RadioButtonList1.DataTextField = "ID";
                    RadioButtonList1.DataValueField = "ID";
                    RadioButtonList1.DataBind();
                }
            }
        }


        protected void Insert_Click(object sender, EventArgs e)
        {

            string name = TextBox1.Text;
            string constr = ConfigurationManager.ConnectionStrings["MysqlConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("Cat_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "INSERT");
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    BindDataControl();
                }
            }
        }

        //update data
        protected void Update_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string constr = ConfigurationManager.ConnectionStrings["MysqlConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("Cat_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "UPDATE");
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Id", RadioButtonList1.SelectedValue);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    BindDataControl();
                }
            }
        }

        //delete data
        protected void Delete_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string constr = ConfigurationManager.ConnectionStrings["MysqlConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("Cat_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "DELETE");
                    cmd.Parameters.AddWithValue("@Id", RadioButtonList1.SelectedValue);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    BindDataControl();
                }
            }
        }
    }
}